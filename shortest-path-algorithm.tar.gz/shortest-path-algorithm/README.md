The format of Input and Output:
Input and Output are invertible.
Case1： For the case of searching shortest path, the input is the weight/cost/utility of each link in the network. The output is the shortest path for each OD pair.
	Input：start node, end node, link cost (free flow travel time, link capacity) --> Output: shortest path
Case2: For the case of traffic assignment. 
	Input: Feasible link flow --> Output: Optimal link flow 
	Input: Feasible path flow --> Output: Optimal path flow
Case 1 serve as a part of Case 2. 
This two case are two key jobs we are going to do in the near feature which serve as the funderment to almost all computation intensive problems in traffic area.
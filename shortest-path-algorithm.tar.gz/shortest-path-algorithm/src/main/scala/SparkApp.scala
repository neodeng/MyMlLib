/**
  * Spark Application that load JNI to calculate the shortest pathes
  * created on: 16/12/12
  */

import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD

class SparkApp(input: String, ls: Int, ns: Int) extends Serializable {
  @transient val sparkConf = new SparkConf().setAppName("SparkApps")
  @transient val sc = new SparkContext(sparkConf)
  val inputFile = sc.textFile(input)
  val inputData = sc.broadcast(inputFile.collect())
  val originArray = sc.parallelize(1 to ns+1, 50)

  /**
    * Method run parallelly
    * return: RDD for writing to hbase
    */
  def run(): Array[(Int, Array[String])] = {
    val result = originArray.map(singleRun)
    val output = result.collect
    output
  }

  /**
    * Single task for one origin point
    * param origin: origin point
    * return: tuple of origin and result
    */
  def singleRun(origin: Int): (Int, Array[String]) = {
    System.loadLibrary("SPscala")
    val spScala = new SPscala
    val result = spScala.SPMain(origin, ls, ns, inputData.value)
    (origin, result)
  }

  /**
    * Method turn result to RDD to write to hBase
    * param tuple: tuple of origin point and shortestpath string
    * return: RDD
    */
  def convert(tuple: (Int, Array[String])) = {
    val rowKey = Utils.getUTCTime().substring(0, 10) + "-" + Utils.getRandStr(8)
    val p = new Put(Bytes.toBytes(rowKey))
    p.addColumn(Bytes.toBytes("result"), Bytes.toBytes("jobId"), Bytes.toBytes(rowKey))
    p.addColumn(Bytes.toBytes("result"), Bytes.toBytes("origin"), Bytes.toBytes(tuple._1.toString))
    p.addColumn(Bytes.toBytes("result"), Bytes.toBytes("shortestpathes"), Bytes.toBytes(tuple._2.mkString("")))
    (new ImmutableBytesWritable, p)
  }
}

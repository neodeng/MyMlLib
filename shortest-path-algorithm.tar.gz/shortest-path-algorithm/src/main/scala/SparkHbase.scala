/**
  * SparkHbase class for hbase connections
  * created on 16/12/14
  */

import org.apache.hadoop.hbase.{HBaseConfiguration, HColumnDescriptor, HTableDescriptor, TableName}
import org.apache.hadoop.hbase.client.{ConnectionFactory, HTable, Put}
import org.apache.hadoop.hbase.util.Bytes


class SparkHbase(hbaseHost: String) {

  private val hbaseConf = HBaseConfiguration.create()
  if (hbaseHost == "") {
    hbaseConf.set("hbase.zookeeper.quorum", SparkHbase.DEFAULT_HOST)
  } else {
    hbaseConf.set("hbase.zookeeper.quorum", hbaseHost)
  }

  /**
    * Method to create hBase Table
    * param table: table name to create
    * param cfs: array of column families
    */
  def createTable(table: String, cfs: Array[String]): Unit = {
    val connection = ConnectionFactory.createConnection(hbaseConf)
    val admin = connection.getAdmin()
    val tableName = TableName.valueOf(table)
    if (!admin.tableExists(tableName)) {
      val hTableDes = new HTableDescriptor(tableName)
      for (cf <- cfs) {
        val hColumnDes = new HColumnDescriptor(cf)
        hTableDes.addFamily(hColumnDes)
      }
      admin.createTable(hTableDes)
    }
    else {
      println(table + " exists!")
    }
  }

  /**
    * Method to delete hBase table
    * param table: table name to delete
    */
  def deleteTable(table: String): Unit = {
    val connection = ConnectionFactory.createConnection(hbaseConf)
    val admin = connection.getAdmin()
    val tableName = TableName.valueOf(table)
    if (admin.tableExists(tableName)) {
      admin.disableTable(tableName)
      admin.deleteTable(tableName)
    }
  }

  /**
    * Method to write SP job info to hBase table
    * param table: table name of JobInfo default to be SPJobsInfo
    * param jobId: string of jobId of format yyyy-MM-dd-xxxxxxxx
    * param userId: string of userId default to be admin
    * param jobStartTime: UTC time when spark job started
    * param jobWallTime: time cost by spark job
    * param codeVersion: code version
    * param cityName: city name for calculation
    * param cityInfo: Line numbers and Point numbers of the city
    * param output: hBase table name for output
    */
  def writeJobInfo(table: String, jobId: String, userId: String, jobStartTime: String, jobWallTime: String,
                   codeVersion: String, cityName: String, cityInfo: String, output: String): Unit = {
    val tableName = if (table == "") SparkHbase.DEFAULT_TABLE else table
    val user = if (userId == "") SparkHbase.dEFAULT_USER else userId
    val hTable = new HTable(hbaseConf, TableName.valueOf(table))
    val thePut = new Put(Bytes.toBytes(jobId))
    thePut.addColumn(Bytes.toBytes("jobInfo"), Bytes.toBytes("jobId"), Bytes.toBytes(jobId))
    thePut.addColumn(Bytes.toBytes("jobInfo"), Bytes.toBytes("userId"), Bytes.toBytes(userId))
    thePut.addColumn(Bytes.toBytes("jobInfo"), Bytes.toBytes("jobStartTimeUTC"), Bytes.toBytes(jobStartTime))
    thePut.addColumn(Bytes.toBytes("jobInfo"), Bytes.toBytes("jobWallTime"), Bytes.toBytes(jobWallTime))
    thePut.addColumn(Bytes.toBytes("jobInfo"), Bytes.toBytes("codeVersion"), Bytes.toBytes(codeVersion))
    thePut.addColumn(Bytes.toBytes("input"), Bytes.toBytes("cityName"), Bytes.toBytes(cityName))
    thePut.addColumn(Bytes.toBytes("input"), Bytes.toBytes("cityInfo"), Bytes.toBytes(cityInfo))
    thePut.addColumn(Bytes.toBytes("output"), Bytes.toBytes("outputTable"), Bytes.toBytes(output))
    hTable.put(thePut)
  }

  /**
    * Method that write spark job results to hBase
    * param table: table name of the calculated city default to be the city name
    * param result: spark RDD
    */
  def writeToTable(cityName: String, result: Array[(Int, Array[String])]) = {
    val hTable = new HTable(hbaseConf, TableName.valueOf(cityName))
    for (singleResult <- result) {
      val rowKey = Utils.getUTCTime().substring(0, 10) + "-" + Utils.getRandStr(8)
      val thePut = new Put(Bytes.toBytes(rowKey))
      thePut.addColumn(Bytes.toBytes("result"), Bytes.toBytes("jobId"), Bytes.toBytes(rowKey))
      thePut.addColumn(Bytes.toBytes("result"), Bytes.toBytes("origin"), Bytes.toBytes(singleResult._1.toString))
      thePut.addColumn(Bytes.toBytes("result"), Bytes.toBytes("shortestpathes"), Bytes.toBytes(singleResult._2.mkString("")))
      hTable.put(thePut)
    }
  }

  /**
    * Method that check the row counts of output table
    * param table: table name to check
    * param ns: row counts expected
    * return false: if rowKey has been duplicated
    */
  def checkTable(table: String, ns: Int): Boolean = {
    // TODO
    true
  }
}

object SparkHbase {

  val DEFAULT_HOST = "localhost"
  val DEFAULT_TABLE = "SPJobsInfo"
  val dEFAULT_USER = "admin"
}


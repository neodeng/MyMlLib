/**
  * Main class for ShortestPath Project
  * created on: 16/12/12
  * created by: physneo
  * code version: 0.1.0
  * description: read input info and start spark application to calculate shortest pathes
  *              write the spark jobinfo and calculated results to hbase
  * param: path of config.xml file
  *        default to be config.xml at current working directory
  * return:
  */

import java.io.FileNotFoundException
import scala.io.Source

class SPscala extends Serializable {

  /**
    * Native method
    * param origin: origin point for calculation
    * param input: string array of input data
    * return: output: string array of calculated shortestpathes results
    */
  @native def SPMain(origin: Int, ls: Int, ns: Int, input: Array[String]) : Array[String]
}

object SPscala {

  /**
    * Main function of the project
    */
  def main(args: Array[String]): Unit = {

    if (args.length != 1 ) throw new IllegalArgumentException("Usage: spark-submit xxx.jar " +
                                                              "[config.xml-path]")
    try {
      val config = Utils.parseXML(args(0))
      val sh = new SparkHbase(config("hbaseHost"))
      sh.createTable(config("hbaseTable"), Array("jobInfo", "input", "output"))

      val userId = config("userId")
      val codeVersion = "0.1.0"

      val inputInfo = Source.fromFile(if (config("formatPath") != "") config("formatPath") else
                                      "Format.txt").mkString

      val format = """(\w+)_net_Simplify\.csv,Ls=(\d+),Ns=(\d+)""".r
      val format(cityName, ls, ns) = inputInfo
      val Ls = ls.toInt
      val Ns = ns.toInt
      val cityInfo = "Ls=" + ls + "," + "Ns=" + ns

      val jobStartTime = Utils.getUTCTime()
      val startTime = System.currentTimeMillis()
      val jobId = jobStartTime.substring(0, 10) + "-" + Utils.getRandStr(8)

      sh.createTable(cityName, Array("result"))
      val input = if (config("csvPath") != "") config("csvPath") else cityName+"_net_Simplify.csv"
      val app = new SparkApp(input, Ls, Ns)
      val output = app.run()
      sh.writeToTable(cityName, output)

      val finishTime = System.currentTimeMillis()
      val jobWallTime = Utils.timeDiffFormat(finishTime - startTime)

      val jobTable = config("hbaseTable")
      sh.writeJobInfo(jobTable, jobId, userId, jobStartTime, jobWallTime, codeVersion, cityName,
                      cityInfo, cityName)
    } catch {
      case fx: FileNotFoundException => println("can not find config.xml or format.txt")
      case me: MatchError => println("The format.txt file's format is not appropriate")
      case nx: NumberFormatException => println("The format.txt file's format is not appropriate")
    }
  }
}



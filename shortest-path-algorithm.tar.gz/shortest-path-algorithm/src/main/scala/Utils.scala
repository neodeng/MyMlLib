/**
  * Some util method defined here
  * parseXML      : static method to parse XML config file
  * getUTCTime    : static method to get current UTC time
  * timeDiffFormat: static method turn millis to hh:mm:ss format
  * getRandStr    : static method to generate rand string for jobId and hbase rowKey
  */

import java.util.{Calendar, Random}
import scala.collection.mutable.ArrayBuffer
import scala.xml.XML

object Utils {

  /**
    * Method to parse config file
    * param xmlFile: the config.xml file path
    * return: Map[String, String]: hbase and input info parsed by config.xml file
    */
  def parseXML(xmlFile: String): Map[String, String] = {
    val confXml = XML.loadFile(xmlFile)
    val hbaseHost = (confXml \ "hbase" \ "host").text
    val userId = (confXml \ "hbase" \ "user").text
    val hbaseTable = (confXml \ "hbase" \ "table").text
    val formatPath = (confXml \ "data" \ "format").text
    val csvPath = (confXml \ "data" \ "csv").text
    Map("hbaseHost" -> hbaseHost, "userId" -> userId, "hbaseTable" -> hbaseTable,
        "formatPath" -> formatPath, "csvPath" -> csvPath)
  }

  /**
    * Method to get UTC time of format yyyy-MM-dd HH:mm
    * return: time string
    */
  def getUTCTime(): String = {
    val cal = Calendar.getInstance()
    val zoneOffset = cal.get(Calendar.ZONE_OFFSET)
    val dstOffset = cal.get(Calendar.DST_OFFSET)
    cal.add(Calendar.MILLISECOND, -zoneOffset)
    cal.add(Calendar.MILLISECOND, -dstOffset)
    val year = cal.get(Calendar.YEAR).toString
    val month = (cal.get(Calendar.MONTH) + 1).toString
    val day = cal.get(Calendar.DAY_OF_MONTH).toString
    val hour = cal.get(Calendar.HOUR_OF_DAY).toString
    val minute = cal.get(Calendar.MINUTE).toString
    val utcTime = year+"-"+month+"-"+day+" "+hour+":"+minute
    utcTime
  }

  /**
    * Method to turn milliseconds to HH:mm:ss format
    * param delTime: milliseconds
    * return: HH:mm:ss format string
    */
  def timeDiffFormat(delTime: Long): String = {
    val seconds = (delTime / 1000 % 60).toString
    val minutes = (delTime / (60 * 1000) % 60).toString
    val hours = (delTime / (60 * 60 * 1000) % 24).toString
    val wallTime = hours + ":" + minutes + ":" + seconds
    wallTime
  }

  /**
    * Method to generate rand string
    * param len: length of rand string
    * return: rand string
    */
  def getRandStr(len: Int): String = {
    val base = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    val rd = new Random()
    val sb = new ArrayBuffer[Char](len)
    for (i <- 0 to len) {
      val ind = rd.nextInt(base.length)
      sb.append(base(ind))
    }
    sb.mkString
  }
}
#!/bin/sh

# build for SPscala
cd ../..
# －Dhttp.proxyHost=localhost -Dhttp.proxyPort=1080
sbt package
cp target/scala-2.10/shortest-path-project_2.10-1.0.jar \
   test/Mac/shortest-path-project_2.10-1.0.jar

# submit jar to spark
# you should have set your SPARK_HOME
# you should replace the path /Users/vvoid/hbase/ with your hbase path
# path of config.xml file should be added
cd test/Mac
bin/spark-submit --class "SPscala" --master spark://xctest:7077 \
--conf "spark.executor.extraLibraryPath=/root/sptest/jars" \
--jars /opt/soft/hbase-1.2.4/lib/hbase-client-1.2.3.jar,\
/opt/soft/hbase-1.2.4/lib/hbase-common-1.2.3.jar,\
/opt/soft/hbase-1.2.4/lib/hbase-hadoop2-compat-1.2.3.jar,\
/opt/soft/hbase-1.2.4/lib/hbase-protocol-1.2.3.jar,\
/opt/soft/hbase-1.2.4/lib/hbase-server-1.2.3.jar,\
/opt/soft/hbase-1.2.4/lib/htrace-core-3.1.0-incubating.jar,\
/opt/soft/hbase-1.2.4/lib/guava-12.0.1.jar,\
/opt/soft/hbase-1.2.4/lib/metrics-core-2.2.0.jar,\
/opt/soft/hbase-1.2.4/lib/zookeeper-3.4.6.jar shortest-path-project_2.10-1.0.jar config.xml


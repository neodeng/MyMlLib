#!/bin/sh

export JAVA_HOME=`/usr/libexec/java_home -v 1.8`
export PATH=/usr/local/share/scala-2.11.8/bin:$PATH

cd scala 
scala -Djava.library.path=$(pwd) -Djava.library.path=../ -cp ./ SPscala

class SPscala {
  // --- Native methods
  @native def SPMain(shortedPath: String) : Int
}

// --- Code in App body will get wrapped in a main method on compilation
object SPscala extends App  {

  // --- Main method to test our native library
  System.loadLibrary("SPscala")

  val SPproject      = new SPscala
  val result = SPproject.SPMain("shorted path")
  
  
  println(s"spCmd return : $result")
}



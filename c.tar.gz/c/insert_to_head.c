#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "1.h"

void insert_to_head(int seq[], int j, int Ns)
{
	//int seq3[Ns * 2] = { 0 };
        int *seq3 = (int*)malloc( 2*Ns*sizeof(int) );
	int node_i;
	seq3[0] = seq[0];
	seq3[1] = j;
	for (node_i = 2; node_i<2 * Ns; node_i++)
	{
		seq3[node_i] = seq[node_i - 1];
	}
	for (node_i = 0; node_i<2 * Ns; node_i++)
	{
		seq[node_i] = seq3[node_i];
	}

        free( seq3 ); 
	return;
}

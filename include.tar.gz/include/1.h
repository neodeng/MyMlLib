// #define Ls 2836
// #define Ns 1052

//void shortest_path(struct L*l, int origin, int pred[]);
int exist_or_not(int seq[], int j, int Ns);
int ever_been_exist_or_not(int j, int seq2[], int Ns);
void insert_to_head(int seq[], int j, int Ns);
void insert_to_end(int seq[], int j);

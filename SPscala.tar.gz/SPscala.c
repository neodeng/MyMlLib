#include "SPscala.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include "1.h"


struct L
{
	int sn, en;
	double capa, fft;

	double ltt;
	double lf, af, lfn;
};

int main(){
    return 0;
}

/*===================== From Scala Call Shorted function ==========================*/
///*
JNIEXPORT jobjectArray JNICALL Java_SPscala_SPMain
(JNIEnv* env, jobject obj, jint origin, jint ls, jint ns, jobjectArray input) {

    jstring jstr;
    jsize len = (*env)->GetArrayLength(env, input);
    char **inputc = (char **) malloc(len*sizeof(char *));
    jsize j = 0;
    for (j=0; j<len; j++) {
        jstr = (*env)->GetObjectArrayElement(env, input, j);
        inputc[j] = (char *)(*env)->GetStringUTFChars(env, jstr, 0);
    }

  //char **outputc = (char **) malloc(1052*sizeof(char *));
  //spmain(origin, inputc, len);

    int link_i,node_i,i;

    int Ls = ls;
    int Ns = ns;

    char outputc[Ns][20];

    struct L *l = (struct L*)malloc( Ls*sizeof(struct L) );

    int *pred = (int*)malloc( (Ns+1)*sizeof(int) );
    //	double weight[Ns + 1] = { 0 };
    double *weight = (double*)malloc( (Ns+1)*sizeof(double) );
    //	int seq[Ns * 2] = { 0 };
    int *seq = (int*)malloc( 2*Ns*sizeof(int) );
    //	int seq2[Ns + 1] = { 0 };
    int *seq2 = (int*)malloc( (Ns+1)*sizeof(int) );

  	for (link_i = 0; link_i<Ls; link_i++){
  		sscanf(inputc[link_i], "%d,%d,%lf,%lf\n", &l[link_i].sn, &l[link_i].en, &l[link_i].capa, &l[link_i].fft);
  	}
  	for (link_i = 0; link_i<Ls; link_i++){
  		l[link_i].ltt=l[link_i].fft;
  	}

  	for (i = 0; i<Ns + 1; i++)
  	{
  		weight[i] = 9999999999;
  		pred[i] = 0;
  		seq2[i] = 0;
  		//printf("%d,%lf,%d\n", i,weight[i], pred[i]);
    }

    for (i = 0; i<Ns*2; i++) {
          seq[i] = 0;
    }

  	weight[origin] = 0; //printf("%lf\n", weight[origin]);
  	seq[0] = origin; //printf("%d\n", seq[0]);
  	node_i = 0;

    int step=0;
  	while (seq[0] != 0){
        step++;
  		for (link_i = 0; link_i<Ls; link_i++){
  			if (l[link_i].sn == seq[0]){
  				if ((weight[l[link_i].sn] + l[link_i].ltt)<weight[l[link_i].en]){
  					weight[l[link_i].en] = (weight[l[link_i].sn] + l[link_i].ltt);//printf("%d,%lf\n", l[link_i].en, weight[l[link_i].en]);
  					pred[l[link_i].en] = l[link_i].sn; //printf("%d,%d\n", l[link_i].sn, l[link_i].en);
  					if (exist_or_not(seq, l[link_i].en, Ns) == 1){
  						if (ever_been_exist_or_not(l[link_i].en, seq2, Ns) == 0){
  							insert_to_head(seq, l[link_i].en, Ns);
  						}
  						else{
  							insert_to_end(seq, l[link_i].en);
  						}
  					}
  				}
  			}
  		}
          //if ( (seq[0] < Ns+1) && (seq[0]>=0) ) {
  	    seq2[seq[0]] = seq[0]; //printf("%d,%d\n", seq[0], seq2[seq[0]]);
          //}
          for (i = 0; i < Ns; i++){
  		    seq[i] = seq[i + 1];
  	    }
  	}

  	for (i = 1; i < Ns+1; i++){
  		sprintf(outputc[i-1],"%d,%d\n", i, pred[i]);
  	}

    jclass stringClass = (*env)->FindClass(env, "java/lang/String");
    jsize outlen = Ns;
    jobjectArray output = (*env)->NewObjectArray(env, outlen, stringClass, 0);
    for (j=0;j<outlen;j++) {
        (*env)->SetObjectArrayElement(env, output, j, (*env)->NewStringUTF(env, outputc[j]));
    }
    free(l);
    free(pred);
    free(weight);
    free(seq);
    free(seq2);
    free(inputc);
    return output;
}



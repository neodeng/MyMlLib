#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "1.h"


int ever_been_exist_or_not(int j, int seq2[], int Ns)
{
	int flag = 1;
	int i;
	for (i = 0; i<(Ns + 1); i++)
	if (j == seq2[i])
		flag = 0;
	return flag;
}

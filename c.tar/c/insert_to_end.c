#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "1.h"

void insert_to_end(int seq[], int j)
{
	int node_i;
	node_i = 0;
	while (seq[node_i] != 0)
	{
		node_i++;
	}
	seq[node_i] = j;

	return;
}

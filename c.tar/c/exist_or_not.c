#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

#include "1.h"

int exist_or_not(int seq[], int j, int Ns)
{
	int flag = 1;
	int node_i;
	for (node_i = 0; node_i<2 * Ns; node_i++)
	{
		if (seq[node_i] == j)
			flag = 0;
	}

	return flag;
}
